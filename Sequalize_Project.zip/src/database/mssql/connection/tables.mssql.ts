export enum Tables{
    Ranjan_Tbl_Department_Details = "Ranjan_Tbl_Department_Details",
    Ranjan_Tbl_Employees_Details = "Ranjan_Tbl_Employees_Details"    
}