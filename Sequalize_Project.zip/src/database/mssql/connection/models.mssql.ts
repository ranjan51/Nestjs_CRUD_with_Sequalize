import { DepartmentDetails } from "../models/department.model";
import { Employee } from "../models/employee.model";
import { MsSqlConstants } from "./constants.mssql";

const msSqlDBModelsProvider = [
    {
        provide: MsSqlConstants.DEPARTMENT_DETAILS_MODEL,
        useValue: DepartmentDetails
    },
    {
        provide: MsSqlConstants.EMPLOYEES_DETAILS_MODEL,
        useValue: Employee
    }
    
 
],
models: any = msSqlDBModelsProvider.map((providers) => providers.useValue);

export { msSqlDBModelsProvider, models };