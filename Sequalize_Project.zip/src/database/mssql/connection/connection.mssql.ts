import { Sequelize } from 'sequelize-typescript';
import { MsSqlConstants } from './constants.mssql';
import { Schema } from './schema.mssql';
import { AppConfigService } from 'src/config/appconfig.service';
import { models } from './models.mssql';

export const sequelizeProvider = [
  {
    provide: MsSqlConstants.SEQUELIZE_PROVIDER,
    useFactory: async (appConfigSvc: AppConfigService) => {
      try {
        const dbConfig = appConfigSvc.get('db').mssql;
        const sequelize = new Sequelize({ ...dbConfig, logging: false });

        await sequelize.authenticate();
        await sequelize.createSchema(Schema.Ranjan_Employees, {});
//using all the models
        sequelize.addModels(models);
        await sequelize.sync();
        console.log("Connected to databse")
        return sequelize;
      } catch (err) {
        console.error('Error connecting to the database:', err);
        throw err;
      }
    },
    inject: [AppConfigService],
  },
];

