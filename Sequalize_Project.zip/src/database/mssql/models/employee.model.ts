// src/employees/employee.model.ts
import { Table, Column, Model, DataType, ForeignKey, PrimaryKey, BelongsTo, Default } from 'sequelize-typescript';
import { DepartmentDetails } from './department.model';
import { Tables } from '../connection/tables.mssql';
import { Schema } from '../connection/schema.mssql';

@Table({
  tableName: Tables.Ranjan_Tbl_Employees_Details,
  schema:Schema.Ranjan_Employees,
  timestamps: false,
})
export class Employee extends Model<Employee> {
  @PrimaryKey 
  @Column({ primaryKey: true, type: DataType.INTEGER,autoIncrement: true })
  employeeID: number;

  @ForeignKey(() => DepartmentDetails)
  @Column({ type: DataType.TINYINT, allowNull: false })
  departmentID: number;

  @Column({ type: DataType.STRING(150), allowNull: false })
  employeeName: string;

  @Column({ type: DataType.STRING(150), allowNull: false ,unique:true})
  email: string;

  @Column({ type: DataType.STRING(6), allowNull: false })
  gender: string;

  @Column({ type: DataType.TINYINT, allowNull: false })
  age: number;

  @Column({ type: DataType.DECIMAL(18, 2), allowNull: false })
  salary: number;

  @Column({ type: DataType.STRING(70), allowNull: false })
  city: string;

  @Column({ type: DataType.BOOLEAN, allowNull: false, defaultValue: true })
  isActive: boolean;

  @Default(DataType.NOW) // Set the default value to the current date and time
  @Column({ type: DataType.DATE, allowNull: false })
  registeredOn: Date;

  @BelongsTo(()=>DepartmentDetails,'departmentID')
  department:DepartmentDetails;
}
