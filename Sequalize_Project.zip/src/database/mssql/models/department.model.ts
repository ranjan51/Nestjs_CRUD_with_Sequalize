import { Column,  Model, PrimaryKey, Table } from "sequelize-typescript";
import { Tables } from "../connection/tables.mssql";
import { Schema } from "../connection/schema.mssql";
import { DataType } from "src/core/enum/data-type.enum";

@Table({tableName :Tables.Ranjan_Tbl_Department_Details,schema:Schema.Ranjan_Employees,timestamps: false })
export class DepartmentDetails extends Model<DepartmentDetails>{
    @PrimaryKey
	@Column({ type: DataType.TINYINT, allowNull: false, autoIncrement: true })
    departmentID: number;

    @Column({type:`${DataType.VARCHAR}(50)`, allowNull: false,unique:true})
    DepartmentName:string

    @Column({type:`${DataType.VARCHAR}(70)`, allowNull: false})
    Location:string;

    @Column({type:`${DataType.VARCHAR}(150)`, allowNull: false})
    DepartmentHeadName:string;
}
   