// src/database/mssql/abstract/department-details-dao.abstract.ts
import { CreateDepartmentDetailsDto, UpdateDepartmentDetailsDto } from '../../../modules/department/dto/department.dto';
import { DepartmentDetails } from '../models/department.model';

export abstract class AbstractDepartmentDetailsDao {
  abstract createDepartmentDetails(createDepartmentDetailsDto: CreateDepartmentDetailsDto): Promise<any>;
  abstract findAllDepartmentDetails(): Promise<any>;
  abstract findDepartmentDetailsById(departmentID: number): Promise<DepartmentDetails | null>;
  abstract updateDepartmentDetails(departmentID: number, updateDepartmentDetailsDto: UpdateDepartmentDetailsDto): Promise<any>;
  abstract deleteDepartmentDetails(departmentID: number): Promise<any>;
}
