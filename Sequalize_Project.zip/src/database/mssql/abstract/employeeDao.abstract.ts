// src/employees/employee.dao.ts
import { AppResponse } from 'src/shared/appresponse.shared';
import { CreateEmployeeDto, UpdateEmployeeDto } from '../../../modules/employee/dto/employee.dto';
import { Employee } from '../models/employee.model';

export abstract class AbstractEmployeeDao {
  abstract createEmployee(createEmployeeDto: CreateEmployeeDto): Promise<AppResponse>;
  abstract findAllEmployees(): Promise<Employee[]>;
  abstract findEmployeeById(employeeID: number): Promise<Employee | null>;
  abstract updateEmployee(employeeID: number, updateEmployeeDto: UpdateEmployeeDto): Promise<AppResponse>;
  abstract deleteEmployee(employeeID: any): Promise<AppResponse>;
  abstract findEmployeesWithDepartments(): Promise<any>;
  abstract updateEmployeei(employee: Employee): Promise<Employee> 

}
