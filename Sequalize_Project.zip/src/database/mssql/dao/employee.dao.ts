// src/employees/employee.dao.ts
import { HttpException, HttpStatus, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Employee } from '../models/employee.model';
import { CreateEmployeeDto, UpdateEmployeeDto } from '../../../modules/employee/dto/employee.dto';
import { MsSqlConstants } from '../connection/constants.mssql';
import { AppResponse, createResponse } from 'src/shared/appresponse.shared';
import { messages } from 'src/shared/messages.shared';
import { UniqueConstraintError } from 'sequelize';
import { AbstractEmployeeDao } from '../abstract/employeeDao.abstract';
import { DepartmentDetails } from '../models/department.model';

// import { AbstractEmployeeDao } from '../abstract/emp.abstract';

@Injectable()
export class EmployeeDao implements AbstractEmployeeDao  {
  constructor(
    @Inject(MsSqlConstants.EMPLOYEES_DETAILS_MODEL)
    private readonly employeeModel: typeof Employee,
    @Inject(MsSqlConstants.DEPARTMENT_DETAILS_MODEL)
    private readonly departmentDetailsModel:typeof DepartmentDetails
  ) {}


  
  async createEmployee(createEmployeeDto: CreateEmployeeDto): Promise<AppResponse> {
    try {
      const maxEmpID:any = await this.employeeModel.max('employeeID');
      const nextEmpID = maxEmpID + 1;
      createEmployeeDto.employeeID=nextEmpID
      const created=await this.employeeModel.create(createEmployeeDto);
      console.log(created);
       return createResponse(HttpStatus.OK,messages.S5,created)
    } catch (error) {
      console.log(error);
      // return createResponse(HttpStatus.UNAUTHORIZED, messages.E1);
      if (error instanceof UniqueConstraintError) {
        const errorMessage = error.errors[0].message;
        return createResponse(HttpStatus.BAD_REQUEST, messages.E2,errorMessage); 
      }
    }
    // return this.employeeModel.create(createEmployeeDto);
  }

  async findAllEmployees(): Promise<Employee[]> {
    return this.employeeModel.findAll();
  }

  async findEmployeeById(employeeID: number): Promise<Employee | null> {
    return this.employeeModel.findByPk(employeeID);
  }

  async updateEmployeei(employee: Employee): Promise<Employee> {
    return employee.save();
  }

  async findEmployeesWithDepartments(): Promise<any> {
    try {
      return await this.employeeModel.findAll({
        include: [
          {
            model: this.departmentDetailsModel,
            required:true,
            right:true
            // attributes: ['DepartmentName'],
          },
        ],
      });
      
    } catch (error) {
      console.log("DAO",error);      
    }
    
  }

  async updateEmployee(employeeID: number, updateEmployeeDto: UpdateEmployeeDto) {
    const [affectedCount, updatedEmployees] = await this.employeeModel.update(updateEmployeeDto, {
      where: { employeeID: employeeID },
      returning: true, // This ensures that Sequelize returns the updated rows
    });
  
    if (affectedCount === 0) {
      // throw new NotFoundException(`Employee with ID ${employeeID} not found.`);
      return createResponse(HttpStatus.BAD_REQUEST,messages.W4)
    }
  
    return createResponse(HttpStatus.OK,messages.S6);
  }
  
  

  async deleteEmployee(employeeID: number): Promise<any> {
    const deletedCount = await this.employeeModel.destroy({
        where: { employeeID: employeeID }, // Use EmployeeID from the DTO
      });
      if (deletedCount === 0) {
        // throw new NotFoundException(`Employee with ID ${employeeID} not found.`);
        return createResponse(HttpStatus.BAD_REQUEST,messages.W4)

      }
      return createResponse(HttpStatus.OK,messages.S7);
  }
  }
