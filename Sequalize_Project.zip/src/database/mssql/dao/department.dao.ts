// src/departments/dao/department-details.dao.ts

import { HttpStatus, Inject, Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { DepartmentDetails } from '../models/department.model';
import { CreateDepartmentDetailsDto, UpdateDepartmentDetailsDto } from '../../../modules/department/dto/department.dto';
import { MsSqlConstants } from '../connection/constants.mssql';
import { AppResponse, createResponse } from 'src/shared/appresponse.shared';
import { messages } from 'src/shared/messages.shared';
import { UniqueConstraintError } from 'sequelize';
import { AbstractDepartmentDetailsDao } from '../abstract/departmentDao.abstract';

@Injectable()
export class DepartmentDetailsDao implements AbstractDepartmentDetailsDao{
  constructor(
    @Inject(MsSqlConstants.DEPARTMENT_DETAILS_MODEL)
    private departmentDetailsModel: typeof DepartmentDetails,
  ) {}

  async createDepartmentDetails(
    createDepartmentDetailsDto: CreateDepartmentDetailsDto,
  ): Promise<AppResponse> {
    try {
      const maxDepartmentID:any = await this.departmentDetailsModel.max('departmentID');
      const nextDepartmentID = maxDepartmentID + 1;
      createDepartmentDetailsDto.departmentID=nextDepartmentID
      const created=await this.departmentDetailsModel.create(createDepartmentDetailsDto);
       return createResponse(HttpStatus.OK,messages.S1,created)
    } catch (error) {
      if (error instanceof UniqueConstraintError) {
        const errorMessage = error.errors[0].message;
        return createResponse(HttpStatus.BAD_REQUEST, messages.E3,errorMessage); 
      }else{
        return createResponse(HttpStatus.UNAUTHORIZED, messages.E1);
    }
    }
  }

  async findAllDepartmentDetails(): Promise<any> {
    try{
    const get= await this.departmentDetailsModel.findAll()
    return get ;
  }catch(error){
    return createResponse(HttpStatus.UNAUTHORIZED, messages.E1);
  }
}

  async findDepartmentDetailsById(
    departmentID: number,
  ): Promise<DepartmentDetails | null> {
    return this.departmentDetailsModel.findByPk(departmentID);
  }

  async updateDepartmentDetails(
    departmentID: number,
    updateDepartmentDetailsDto: UpdateDepartmentDetailsDto,
  ): Promise<any> {
    const affectedCount :any= await this.departmentDetailsModel.update(updateDepartmentDetailsDto, {
      where: { departmentID },
      returning: true,
    });
  
    if (affectedCount === 0) {
      // throw new NotFoundException(`Employee with ID ${employeeID} not found.`);
      return createResponse(HttpStatus.BAD_REQUEST,messages.W5)
    }
  
    return createResponse(HttpStatus.OK,messages.S6);
  }
  

  async deleteDepartmentDetails(departmentID: number): Promise<any> {

    const deletedCount = await this.departmentDetailsModel.destroy({
      where: { departmentID }, 
    });
    if (deletedCount === 0) {
      // throw new NotFoundException(`Employee with ID ${employeeID} not found.`);
      return createResponse(HttpStatus.BAD_REQUEST,messages.W5)

    }
    return createResponse(HttpStatus.OK,messages.S10);
  }
}
