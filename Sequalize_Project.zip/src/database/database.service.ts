import { Injectable } from "@nestjs/common";
import { AbstractEmployeeDao } from "./mssql/abstract/employeeDao.abstract";
import { AbstractDepartmentDetailsDao } from "./mssql/abstract/departmentDao.abstract";

@Injectable()
export class DatabaseService{
    constructor(
        public empSqlTxn:AbstractEmployeeDao,
        public deptSqlTxn:AbstractDepartmentDetailsDao
    ){}
}