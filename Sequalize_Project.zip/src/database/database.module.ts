import { Global, Module } from "@nestjs/common";
import { DatabaseService } from "./database.service";
import { sequelizeProvider } from "./mssql/connection/connection.mssql";
import { msSqlDBModelsProvider } from "./mssql/connection/models.mssql";
import { AppConfigService } from "src/config/appconfig.service";
import { AbstractEmployeeDao } from "./mssql/abstract/employeeDao.abstract";
import { EmployeeDao } from "./mssql/dao/employee.dao";
import { AbstractDepartmentDetailsDao } from "./mssql/abstract/departmentDao.abstract";
import { DepartmentDetailsDao } from "./mssql/dao/department.dao";
@Global()
@Module({
	providers: [
		...sequelizeProvider,//connection
		...msSqlDBModelsProvider, //it makes to accessable inside db folder
		DatabaseService,
		AppConfigService,
		{
			provide:AbstractEmployeeDao,
			useClass:EmployeeDao
		},
		{
			provide:AbstractDepartmentDetailsDao,
			useClass:DepartmentDetailsDao
		}
	],
	exports: [
		...msSqlDBModelsProvider,
		...sequelizeProvider,
		DatabaseService,
		{
			provide:AbstractEmployeeDao,
			useClass:EmployeeDao
		},
		{
			provide:AbstractDepartmentDetailsDao,
			useClass:DepartmentDetailsDao
		}
	]
})
export class DatabaseModule {}
