import { NestFactory } from '@nestjs/core';
import { AppModule } from './modules/app/app.module';
import { AppConfigService } from './config/appconfig.service';
import { ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

async function bootstrap() {
  const app = await NestFactory.create(AppModule),
    configObj = app.get(AppConfigService),
    appConfig = configObj.get('app'),
    { port } = appConfig;
  // Enable CORS here
  // app.enableCors({
  //   origin: 'http://localhost:3000', // Replace with your frontend's actual domain
  //   methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
  //   credentials: true, // This allows cookies to be sent and received across domains if you are using cookies for authentication
  // });  
  app.useGlobalPipes(new ValidationPipe());
  const options = new DocumentBuilder()
    .setTitle('Employees API')
    .setDescription('API for managing Employees')
    .setVersion('1.0')
    .addTag('products')
    .build();
  const document = SwaggerModule.createDocument(app, options);
  SwaggerModule.setup('api', app, document);
  await app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
}
bootstrap();
