class CommonRegExp {
	
	public static readonly EMAIL_REGEXP = /^[a-zA-Z][a-zA-Z0-9._\-]*@\w+\.\w+$/;
	
	
}

export { CommonRegExp };
