export function messageFactory(message: string, msgParams?: string[]): string {
	let newMsg = message;
	if (msgParams && msgParams.length > 0) {
		msgParams.forEach((val, key) => {
			newMsg = newMsg.split(`ARG${key}`).join(val?.toString());
		});
	}
	return newMsg;
}

export const enum messages {
	//ARG0,ARG1 ... ARGn should be in sequence.

	//Genaral messages : Start with Gn
	G1 = 'Profit or Loss',
	//Success messages : Start with Sn
	S1 = 'New Department Added!',
	S2 = 'All Departments',
	S3 = 'Connected to SQL server!',
	S4 = 'Success',
	S5 = 'Employee has been registered successfully.',
	S6 = 'Employee details updated successfully.',
	S7 = 'Employee details deleted successfully.',
	S8 = 'Department has been registered successfully.',
	S9 = 'Department details updated successfully.',
	S10 = 'Department details deleted successfully.',
	S11 = 'COGS added successfully',
	S12 = 'COGS updated successfully',
	S13 = 'COGS deleted successfully',
	S14 = 'Customer invoice(s) added successfully ',
	S15 = 'Customer invoice updated successfully',
	S16 = 'Customer invoice deleted successfully',
	S17 = 'COGS invoice(s) added successfully',

	//Warning messages : Start with Wn
	W1 = 'Please provide a valid details',
	W2 = 'ARG0 should not be empty!',
	W3 = 'Please provide a valid ARG0',
	W4 = `Employee not found.`,
	W5 = 'Department not found',
	W6 = 'ARG0 value should be ARG1 or ARG2',
	W7 = 'The provided email address is already associated with an existing account. Please double-check or try a different email.',
	W8 = 'It seems the provided email address is not registered within our organization. Please ensure you have entered the correct address.',
	W9 = 'We apologize for the inconvenience, but updating your own account directly is not permitted. Kindly reach out to our support team for help.',
	W10 = 'Uploaded file format is not allowed. Only .csv format is allowed!',
	W11 = 'The file size should not exceed ARG0 MB. Please make sure to upload file within the specified size limit.',
	W12 = 'ARG0 value should be ARG1, ARG2 or ARG3',
	W13 = 'ARG0 should not exceed more than ARG1 characters.',
	W14 = 'The provided invoice number is already associated with existing invoice .Please provide a valid invoice number',
	W15 = 'The total invoice amount should equal the sum of the partial payment and the due amount.',
	W16 = 'Please provide atleast one field',
	W17 = 'Uploaded file format is not allowed. Only .csv format is allowed!',
	W18 = 'No record found with this ARG0 id',
	W19 = 'Already deleted',
	W20 = 'If payment is not fully paid please provide partial payment amount and due amount',
	W21 = 'An error ocurred while processing your data please check the data provide and try again',
	W22 = 'ARG0 must be an array',
	W23 = 'This user is already disabled, So please enable the user to update details',
	W25 = 'No Record found from the csv file',
	W26 = 'The file size should not exceed ARG0 MB. Please make sure to upload an file within the specified size limit.',
	W27 = 'The date range you provided exceeds the maximum allowed range of 12 months.',
	W28 = 'The end date must be greater than the start date.',
	W29 = 'The payment date cannot be earlier than the invoice date.',
	W30 = 'The total amount provided matches the partial payment amount. You can mark it as fully paid.',
	W31 = 'Payment status cannot be altered.',
	W32 = 'No records were found for the provided date range.',
	W33 = ' Partial payment date cannot be greater than current date',
	W34 = 'Payment date cannot be greater than current date ',
	W35 = 'Some row(s) have missing values in required ARG0 column',
	W36 = 'Some row(s) have invalid values in the ARG0 column',
	W37 = 'Some row(s) ARG0 greater than the current ARG1.',
	W38 = 'Some row(s) have values in the ARG0 and ARG1 columns are not in the same month.',
	W39 = 'At least one ARG0 required!',
	W40 = 'You cannot switch to the same role !',
	W41 = "Currently,you don't have the required role permissions to make this switch.",

	// Email message : Start with Mn

	//Error messages : Start with En
	E1 = 'Something went wrong :(',
	E2 = 'Email Id already exist',
	E3 = 'Department name already exist',
	E4 = 'An error occurred while establishing connection to SQL server! (ERROR :: ARG0)',
	E5 = 'SQL database connection disconnected through app termination!',
	E6 = 'Error closing SQL database connection! (ERROR :: ARG0)!',
	E7 = 'We are sorry, but you do not have access to this resource [ARG0]!',
	E8 = 'ARG0 "ARG1" not supported.',
	E9 = 'We regret to inform you that an error occurred while authenticating your credentials. Please retry the authentication process!',
	E10 = 'User session not found',
	E11 = 'User doesnt exists'
}
