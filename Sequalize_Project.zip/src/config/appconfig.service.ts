export class AppConfigService {
  private readonly envConfig: { [key: string]: any } = {};
  constructor() {
    /*app configurations*/
    this.envConfig.app = {
      port: parseInt(process.env.APP_PORT, 10) || 8800,
    };

    /*database connection*/
    this.envConfig.db = {
      mssql: {
        dialect: 'mssql',
        database: process.env.MSSQL_DATABASE,
        username: process.env.MSSQL_USERNAME,
        password:process.env.MSSQL_PASSWORD,
        host: process.env.MSSQL_SERVER,
        port: 1433,
        trustServerCertificate: Boolean(
          process.env.MSSQL_TRUST_SERVER_CERTIFICATE,
        ),
       
      },
    };
  }

  get(key: string): any {
    return this.envConfig[key];
  }
}
