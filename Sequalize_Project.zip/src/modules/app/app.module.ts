import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { DatabaseModule } from 'src/database/database.module';
import { ConfigModule } from '@nestjs/config';
import { AppConfigService } from 'src/config/appconfig.service';
import { DepartmentModule } from '../department/department.module';
import { EmployeesModule } from '../employee/employee.module';

@Module({
  imports: [ConfigModule.forRoot(),AppConfigService,DatabaseModule,DepartmentModule,EmployeesModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
