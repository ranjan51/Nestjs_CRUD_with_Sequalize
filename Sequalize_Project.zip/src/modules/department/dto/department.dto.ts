// src/departments/dto/department-details.dto.ts

import { Transform, TransformFnParams } from 'class-transformer';
import { IsNotEmpty, IsString, IsInt } from 'class-validator';
import { messageFactory, messages } from 'src/shared/messages.shared';

export class CreateDepartmentDetailsDto {
  // @IsInt()
  departmentID: number;

  @IsString()
  @IsNotEmpty({ message: messageFactory(messages.W2, ['DepartmentName']) })
  @Transform(({ value }: TransformFnParams) => value?.trim())
  DepartmentName: string;
  
  @IsString()
  @IsNotEmpty({ message: messageFactory(messages.W2, ['Location']) })
  @Transform(({ value }: TransformFnParams) => value?.trim())
  Location: string;

  @IsString()
  @IsNotEmpty()
  DepartmentHeadName: string;
}

export class UpdateDepartmentDetailsDto {
  departmentID?: number;

  @IsString()
  @IsNotEmpty({ message: 'Location should not be empty' })
  @Transform(({ value }: TransformFnParams) => value?.trim())
  Location?: string;

  @IsString()
  @IsNotEmpty({ message: 'DepartmentHeadName should not be empty' })
  DepartmentHeadName?: string;
}
