// src/departments/department-details.controller.ts
import { Controller, Get, Post, Body, Param, Put, Delete } from '@nestjs/common';
import { DepartmentDetailsService } from './department.service';
import { CreateDepartmentDetailsDto, UpdateDepartmentDetailsDto } from './dto/department.dto';
import { ApiTags } from '@nestjs/swagger';
import { AbstractDepartmentDetailsService } from './department.abstract';
@ApiTags('departments')
@Controller('departments')
export class DepartmentDetailsController {
  constructor(private readonly departmentDetailsService: AbstractDepartmentDetailsService) {}

  @Post()
  create(@Body() createDepartmentDetailsDto: CreateDepartmentDetailsDto) 
  {

    return this.departmentDetailsService.create(createDepartmentDetailsDto);

  }

  @Get()
  findAll() {
    return this.departmentDetailsService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.departmentDetailsService.findOne(+id);
  }

  @Put(':id')
  update(@Param('id') id: string, @Body() updateDepartmentDetailsDto: UpdateDepartmentDetailsDto) {
    return this.departmentDetailsService.update(+id, updateDepartmentDetailsDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.departmentDetailsService.remove(+id);
  }
}