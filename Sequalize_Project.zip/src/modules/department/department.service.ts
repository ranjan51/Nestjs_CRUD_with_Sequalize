// src/departments/department-details.service.ts

import { Injectable } from '@nestjs/common';
import { DepartmentDetails } from '../../database/mssql/models/department.model';
import { CreateDepartmentDetailsDto, UpdateDepartmentDetailsDto } from './dto/department.dto';
import { DepartmentDetailsDao } from '../../database/mssql/dao/department.dao';
import { AbstractDepartmentDetailsDao } from 'src/database/mssql/abstract/departmentDao.abstract';
import { DatabaseService } from 'src/database/database.service';
import { AbstractDepartmentDetailsService } from './department.abstract';

@Injectable()
export class DepartmentDetailsService implements AbstractDepartmentDetailsService {
  private readonly departmentDetailsDao: AbstractDepartmentDetailsDao
  constructor(private readonly _dbSvc:DatabaseService) {
    this.departmentDetailsDao=this._dbSvc.deptSqlTxn
  }

  async create(createDepartmentDetailsDto: CreateDepartmentDetailsDto) {
    
    
    return this.departmentDetailsDao.createDepartmentDetails(createDepartmentDetailsDto);
  }

  async findAll() {
    return this.departmentDetailsDao.findAllDepartmentDetails();
  }

  async findOne(departmentID: number) {
    return this.departmentDetailsDao.findDepartmentDetailsById(departmentID);
  }

  async update(departmentID: number, updateDepartmentDetailsDto: UpdateDepartmentDetailsDto): Promise<[number, DepartmentDetails[]]> {
    return this.departmentDetailsDao.updateDepartmentDetails(departmentID, updateDepartmentDetailsDto);
  }

  async remove(departmentID: number): Promise<number> {
    return this.departmentDetailsDao.deleteDepartmentDetails(departmentID);
  }
}
