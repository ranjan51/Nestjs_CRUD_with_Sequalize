// src/database/mssql/abstract/department-service.abstract.ts
import { CreateDepartmentDetailsDto, UpdateDepartmentDetailsDto } from '../../modules/department/dto/department.dto';
import { DepartmentDetails } from '../../database/mssql/models/department.model';

export abstract class AbstractDepartmentDetailsService {

  abstract create(createDepartmentDetailsDto: CreateDepartmentDetailsDto): Promise<any>;
  abstract findAll(): Promise<any>;
  abstract findOne(departmentID: number): Promise<DepartmentDetails | null>;
  abstract update(departmentID: number, updateDepartmentDetailsDto: UpdateDepartmentDetailsDto): Promise<any>;
  abstract remove(departmentID: number): Promise<number>;
}
