// src/departments/department.module.ts

import { Module } from '@nestjs/common';
import { SequelizeModule } from '@nestjs/sequelize';
import { DepartmentDetails } from '../../database/mssql/models/department.model';
import { DepartmentDetailsController } from './department.controller';
import { DepartmentDetailsService } from './department.service';
import { DepartmentDetailsDao } from '../../database/mssql/dao/department.dao';
import { AbstractDepartmentDetailsService } from './department.abstract';

@Module({
  imports: [],
  controllers: [DepartmentDetailsController],
  providers: [{
    provide:AbstractDepartmentDetailsService,
    useClass:DepartmentDetailsService
  }]
  // providers:[DepartmentDetailsService,DepartmentDetailsDao]
})

export class DepartmentModule {}
