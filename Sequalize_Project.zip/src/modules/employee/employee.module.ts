import { Module } from '@nestjs/common';
import { SequelizeModule } from '@nestjs/sequelize';
import { Employee } from '../../database/mssql/models/employee.model';
import { EmployeesController } from './employee.controller';
import { EmployeesService } from './employee.service';
import { EmployeeDao } from '../../database/mssql/dao/employee.dao';
import { AbstractEmployeeService } from './employee.abstract';

@Module({
  imports: [],
  controllers: [EmployeesController],
  providers: [{
    provide:AbstractEmployeeService,
    useClass:EmployeesService
  }],
})
export class EmployeesModule {}
