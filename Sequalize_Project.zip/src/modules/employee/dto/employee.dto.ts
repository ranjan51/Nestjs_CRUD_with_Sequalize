import { IsNotEmpty, IsEmail, IsString, IsInt, IsBoolean, IsDate, Min, IsEnum, IsNumber, Matches, IsOptional } from 'class-validator';
import { messageFactory, messages } from 'src/shared/messages.shared';
import { CommonRegExp } from 'src/shared/regex.shared';

export class CreateEmployeeDto {

  // @IsInt()
  employeeID: number;

  @IsInt()
  departmentID: number;

  @IsString()
  employeeName: string;

  // @IsEmail()
  @IsNotEmpty({ message: messageFactory(messages.W2, ['Email id']) })
	@Matches(CommonRegExp.EMAIL_REGEXP, { each: true, message: messageFactory(messages.W3, ['email-id']) })
  email: string;

  @IsEnum(['Male', 'Female', 'Other'])
  gender: string;

  @IsInt()
  age: number;

  @IsNumber()
  salary: number;

  @IsString()
  city: string;

  // @IsBoolean()
  isActive: boolean;

  // @IsDate()
  registeredOn: Date;
}


export class UpdateEmployeeDto {
  @IsOptional()
  @IsInt()
  departmentID?: number;

  @IsOptional()
  @IsString()
  employeeName?: string;

  @IsOptional()
  @IsEnum(['Male', 'Female', 'Other'])
  gender?: string;

  @IsOptional()
  @IsInt()
  age?: number;

  @IsOptional()
  @IsNumber()
  salary?: number;

  @IsOptional()
  @IsString()
  city?: string;

  isActive?: boolean;

  registeredOn?: Date;
}


