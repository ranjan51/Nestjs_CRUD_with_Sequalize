// src/employees/employees.service.ts
import { Injectable, NotFoundException } from '@nestjs/common';
import { Employee } from '../../database/mssql/models/employee.model';
import { CreateEmployeeDto, UpdateEmployeeDto } from './dto/employee.dto';
import { EmployeeDao } from '../../database/mssql/dao/employee.dao';
import { DatabaseService } from 'src/database/database.service';
import { AbstractEmployeeDao } from 'src/database/mssql/abstract/employeeDao.abstract';
import { AbstractEmployeeService } from './employee.abstract';

@Injectable()
export class EmployeesService implements AbstractEmployeeService{
  private readonly employeeDao: AbstractEmployeeDao
  constructor(private readonly _dbSvc:DatabaseService) {
    this.employeeDao=this._dbSvc.empSqlTxn
  }

  async create(createEmployeeDto: CreateEmployeeDto){
    return this.employeeDao.createEmployee(createEmployeeDto);
  }

  async findAll(): Promise<Employee[]> {
    return this.employeeDao.findAllEmployees();
  }

  async findOne(employeeID: number): Promise<Employee | null> {
    return this.employeeDao.findEmployeeById(employeeID);
  }

  async findEmployeesWithDepartments(): Promise<any> {
    try{
      // console.log('hi');
      
    return this.employeeDao.findEmployeesWithDepartments();
    }catch(error){
      console.log("error",error);  
      }
  }

  async update(employeeID: number, updateEmployeeDto:UpdateEmployeeDto) {
    return this.employeeDao.updateEmployee(employeeID, updateEmployeeDto);
  }

  async toggleEmployeeActiveStatus(id: number, isActive: boolean): Promise<any> {
    const employee = await this.employeeDao.findEmployeeById(id);

    if (!employee) {
      throw new NotFoundException(`Employee with ID ${id} not found.`);
    }

    employee.isActive = isActive;
    return this.employeeDao.updateEmployeei(employee);
  }

  async remove(employeeID: number): Promise<any> {
    return this.employeeDao.deleteEmployee(employeeID);
  }
}
