// src/employees/employees.controller.ts
import { Controller, Get, Post, Body, Param, Put, Delete, Res, Patch } from '@nestjs/common';
import { EmployeesService } from './employee.service';
import { CreateEmployeeDto, UpdateEmployeeDto } from './dto/employee.dto';
import { ApiTags } from '@nestjs/swagger';
import { AbstractEmployeeService } from './employee.abstract';
import { Response } from 'express';
import { waitForDebugger } from 'inspector';


@ApiTags('employees')
@Controller('employees')
export class EmployeesController {
  constructor(private readonly employeesService: AbstractEmployeeService) {}

  @Post()
  async create(@Body() createEmployeeDto: CreateEmployeeDto) {
    // console.log(createEmployeeDto);
    
    
    return this.employeesService.create(createEmployeeDto);
  }

  @Get('get')
  async findAll() {
    return this.employeesService.findAll();
  }


  @Get(':id')
  async findOne(@Param('id') id: string) {
    return this.employeesService.findOne(+id);
  }

  // @Get('')
  // async get(){
  //   return 'hello'
  // }


  @Get('with-departments')
  async findEmployeesWithDepartments() {
   try {
     const get = this.employeesService.findEmployeesWithDepartments();
     return get
   } catch (error) {
    console.log("error",error);
    
   } 
  }

  @Put('put/:id')
  async update(@Param('id') id: string, @Body() updateEmployeeDto: UpdateEmployeeDto) {
    return this.employeesService.update(+id, updateEmployeeDto);
  }

  @Patch('patch/:id')
  async toggleEmployeeActiveStatus(@Param('id') id: number, @Body() updateEmployeeDto: UpdateEmployeeDto) {
    const isActive = updateEmployeeDto.isActive;
    return this.employeesService.toggleEmployeeActiveStatus(id, isActive);
  }

  @Delete('delete/:id')
  async remove(@Param('id') id: string) {
    return this.employeesService.remove(+id);
  }
}
