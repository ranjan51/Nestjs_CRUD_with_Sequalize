// src/database/mssql/abstract/employee-service.abstract.ts
import { CreateEmployeeDto, UpdateEmployeeDto } from '../employee/dto/employee.dto';
import { Employee } from '../../database/mssql/models/employee.model';

export abstract class AbstractEmployeeService {
  abstract create(createEmployeeDto: CreateEmployeeDto): Promise<any>;
  abstract findAll(): Promise<Employee[]>;
  abstract findOne(employeeID: number): Promise<Employee | null>;
  abstract update(employeeID: number, updateEmployeeDto: UpdateEmployeeDto): Promise<any>;
  abstract remove(employeeID: number): Promise<number>;
  abstract findEmployeesWithDepartments(): Promise<any>;
  abstract toggleEmployeeActiveStatus(id: number, isActive: boolean): Promise<any>
  
}
