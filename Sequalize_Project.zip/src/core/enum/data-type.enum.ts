export enum DataType {
	VARCHAR = 'VARCHAR',
	INT = 'INT',
	TINYINT = 'TINYINT',
	BIT = 'BIT',
	DATE = 'DATE',
	DECIMAL = 'DECIMAL'
}
